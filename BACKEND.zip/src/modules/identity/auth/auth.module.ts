import {
  Module,
} from '@nestjs/common';

import {
  ConfigModule,
  ConfigService,
} from '@nestjs/config';

import {
  JwtModule,
} from '@nestjs/jwt';

import {
  MailModule,
} from '../../../infrastructure/mail/mail.module.js';

import {
  AuthorizationModule,
} from '../authorization/authorization.module.js';

import {
  AuthController,
} from './auth.controller.js';

import {
  AuthService,
} from './auth.service.js';

import {
  AccessTokenGuard,
} from './guards/access-token.guard.js';

import {
  AuthRateLimitGuard,
} from './guards/auth-rate-limit.guard.js';

import {
  AuthCookieGuard,
} from './guards/auth-cookie.guard.js';

@Module({
  imports: [
    ConfigModule,

    JwtModule.registerAsync({
      imports: [
        ConfigModule,
      ],
    
      inject: [
        ConfigService,
      ],
    
      useFactory: (
        configService: ConfigService,
      ) => ({
        secret:
          configService.getOrThrow<string>(
            'JWT_ACCESS_SECRET',
          ),
    
        signOptions: {
          algorithm: 'HS256',
          issuer: 'minrex-api',
          audience: 'minrex-api:access',
        },
    
        verifyOptions: {
          algorithms: ['HS256'],
          issuer: 'minrex-api',
          audience: 'minrex-api:access',
          ignoreExpiration: false,
        },
      }),
    }),

    MailModule,

    AuthorizationModule,
  ],

  controllers: [
    AuthController,
  ],

  providers: [
    AuthService,
    AccessTokenGuard,
    AuthRateLimitGuard,
    AuthCookieGuard
  ],

  exports: [
    AuthService,
    JwtModule,
    AccessTokenGuard,
  ],
})
export class AuthModule {}